/**
 * 
 */
package test.app.rental.trip.fare;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import app.rental.bo.FareRate;
import app.rental.bo.TripDetailsInfo;
import app.rental.bo.VehicleBasicInfo;
import app.rental.bo.VehicleFuelType;
import app.rental.bo.VehicleInfo;
import app.rental.bo.VehicleType;
import app.rental.exception.BusinessException;
import app.rental.service.FareCalulatorService;

/**
 * @author Ankush Kumar
 *
 */

public class FareCalculatorTest {

    private TripDetailsInfo tripDetailsInfo;

    private VehicleInfo vehicleInfo;

    private VehicleBasicInfo vehicleBasicInfo;

    private FareRate fareRate;

    private FareCalulatorService fareCalculator = new FareCalulatorService();

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
        tripDetailsInfo = new TripDetailsInfo();
        tripDetailsInfo.setNoOfPassengers(12);
        tripDetailsInfo.setTripDistance(1000);

        fareRate = new FareRate();
        fareRate.setExtraPassengerPerKmRate(1);
        fareRate.setPerKmACRate(2);
        fareRate.setStandardRate(15);

    }

    @Test(expected = BusinessException.class)
    public final void testpopulateFareDetailsAndCalculateFarewithTripException()
            throws BusinessException {

        tripDetailsInfo = null;

        assertEquals(17640.000008046627, fareCalculator
                .populateFareDetailsAndCalculateFare(tripDetailsInfo));

    }

    @Test(expected = BusinessException.class)
    public final void testpopulateFareDetailsAndCalculateFarewithFareException()
            throws BusinessException {
        vehicleBasicInfo = new VehicleBasicInfo();
        vehicleBasicInfo.setACEnabled(true);
        vehicleBasicInfo.setPassengerLimit(10);

        vehicleInfo = new VehicleInfo();
        vehicleInfo.setFareRate(null);
        vehicleInfo.setVehicleBasicInfo(vehicleBasicInfo);
        vehicleInfo.setVehicleFuelType(VehicleFuelType.DIESEL);
        vehicleInfo.setVehicleType(VehicleType.SEDAN);
        tripDetailsInfo.setVehicleInfo(vehicleInfo);

        assertEquals(17640.000008046627, fareCalculator
                .populateFareDetailsAndCalculateFare(tripDetailsInfo));

    }

    @Test
    public final void testpopulateFareDetailsAndCalculateFareForDieselBus() {

        vehicleBasicInfo = new VehicleBasicInfo();
        vehicleBasicInfo.setACEnabled(true);
        vehicleBasicInfo.setPassengerLimit(10);

        vehicleInfo = new VehicleInfo();
        vehicleInfo.setFareRate(fareRate);
        vehicleInfo.setVehicleBasicInfo(vehicleBasicInfo);
        vehicleInfo.setVehicleFuelType(VehicleFuelType.DIESEL);
        vehicleInfo.setVehicleType(VehicleType.BUS);
        tripDetailsInfo.setVehicleInfo(vehicleInfo);

        try {
            assertEquals(17640.000008046627, fareCalculator
                    .populateFareDetailsAndCalculateFare(tripDetailsInfo));
        } catch (BusinessException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    @Test
    public final void testpopulateFareDetailsAndCalculateFareForPetrolCar() {
        vehicleBasicInfo = new VehicleBasicInfo();
        vehicleBasicInfo.setACEnabled(true);
        vehicleBasicInfo.setPassengerLimit(12);

        vehicleInfo = new VehicleInfo();
        vehicleInfo.setFareRate(fareRate);
        vehicleInfo.setVehicleBasicInfo(vehicleBasicInfo);
        vehicleInfo.setVehicleFuelType(VehicleFuelType.PETROL);
        vehicleInfo.setVehicleType(VehicleType.SEDAN);
        tripDetailsInfo.setVehicleInfo(vehicleInfo);

        try {
            assertEquals(17000, fareCalculator
                    .populateFareDetailsAndCalculateFare(tripDetailsInfo));
        } catch (BusinessException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

}
