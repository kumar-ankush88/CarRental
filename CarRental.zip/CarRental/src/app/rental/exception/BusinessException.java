/**
 * 
 */
package app.rental.exception;

/**
 * @author Ankush Kumar
 *
 */
public class BusinessException extends Exception {

    public BusinessException(String message) {
        super(message);
    }
}
