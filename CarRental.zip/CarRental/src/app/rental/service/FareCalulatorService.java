/**
 * 
 */
package app.rental.service;

import app.rental.bo.TripDetailsInfo;
import app.rental.bo.VehicleFuelType;
import app.rental.bo.VehicleInfo;
import app.rental.bo.VehicleType;
import app.rental.exception.BusinessException;

/**
 * @author Ankush Kumar
 *
 */
public class FareCalulatorService {

    private final float reductionOfStandardFareForDieselVehicle = 1;

    private final float discountPercentage = 2;

    /**
     * Populates the value for the discount percentage based on the vehicletype and calls the calculateFare method.
     *     * 
     * @param trip
     *            a TripDetailsInfo object containing the
     *            information we need for the trip and vehicle used for the trip
     * @return a double value for the fare.
     * @throws BusinessException 
     *        
     */

    public double populateFareDetailsAndCalculateFare(TripDetailsInfo trip)
            throws BusinessException {
        if ((trip != null) && trip.getVehicleInfo() != null) {
            VehicleInfo vehicle = trip.getVehicleInfo();

            if (vehicle.getVehicleType().equals(VehicleType.BUS)) {
                vehicle.getFareRate().setDiscountPercent(discountPercentage);
                trip.setVehicleInfo(vehicle);
            }

            return calculateFare(trip);
        }

        else {
            throw new BusinessException("Trip Details Not found");
        }

    }

    /**
     * Calculates the fare for a given Trip
     *     * 
     * @param trip
     *            a TripDetailsInfo object containing the
     *            information we need for the trip and vehicle used for the trip
     * @return a double value for the fare.
     *        
     */
    private double calculateFare(TripDetailsInfo trip) throws BusinessException {
        VehicleInfo vehicle = trip.getVehicleInfo();
        double totalFare = 0;
        if (vehicle.getFareRate() != null) {
            double standardFare = vehicle.getFareRate().getStandardRate();

            if (trip.getNoOfPassengers() > vehicle.getVehicleBasicInfo()
                    .getPassengerLimit()) {
                standardFare += vehicle.getFareRate()
                        .getExtraPassengerPerKmRate()
                        * (trip.getNoOfPassengers() - vehicle
                                .getVehicleBasicInfo().getPassengerLimit());
            }

            if (vehicle.getVehicleBasicInfo().isACEnabled()) {
                standardFare += vehicle.getFareRate().getPerKmACRate();
            }

            if (vehicle.getVehicleFuelType().equals(VehicleFuelType.DIESEL)) {
                standardFare -= reductionOfStandardFareForDieselVehicle;
            }

            if (vehicle.getFareRate().getDiscountPercent() > 0) {
                standardFare -= (vehicle.getFareRate().getDiscountPercent() / 100)
                        * standardFare;
            }

            totalFare = standardFare * trip.getTripDistance();
            return totalFare;
        } else {
            throw new BusinessException("vehicle Fare details not found");
        }

    }
}
