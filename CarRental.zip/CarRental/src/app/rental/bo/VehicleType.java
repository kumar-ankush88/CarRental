package app.rental.bo;

public enum VehicleType {
    SEDAN, HATCHBACK, SUV, BUS;
}
