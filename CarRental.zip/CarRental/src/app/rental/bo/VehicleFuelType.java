package app.rental.bo;

public enum VehicleFuelType {
    PETROL, DIESEL;
}
