/**
 * 
 */
package app.rental.bo;

import java.io.Serializable;

/**
 * @author Ankush Kumar
 *
 */
public class VehicleInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    private VehicleBasicInfo vehicleBasicInfo;

    private VehicleType vehicleType;

    private VehicleFuelType vehicleFuelType;

    private FareRate fareRate;

    public VehicleInfo() {
    }

    public VehicleBasicInfo getVehicleBasicInfo() {
        return vehicleBasicInfo;
    }

    public void setVehicleBasicInfo(VehicleBasicInfo vehicleBasicInfo) {
        this.vehicleBasicInfo = vehicleBasicInfo;
    }

    public VehicleType getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(VehicleType vehicleType) {
        this.vehicleType = vehicleType;
    }

    public VehicleFuelType getVehicleFuelType() {
        return vehicleFuelType;
    }

    public void setVehicleFuelType(VehicleFuelType vehicleFuelType) {
        this.vehicleFuelType = vehicleFuelType;
    }

    public FareRate getFareRate() {
        return fareRate;
    }

    public void setFareRate(FareRate fareRate) {
        this.fareRate = fareRate;
    }

}
