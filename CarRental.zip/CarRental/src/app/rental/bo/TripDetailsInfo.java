/**
 * 
 */
package app.rental.bo;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Ankush Kumar
 *
 */
public class TripDetailsInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    private double tripDistance;

    private Date startDate;

    private Date endDate;

    private int noOfPassengers;

    private VehicleInfo vehicleInfo;

    public TripDetailsInfo() {
    }

    public double getTripDistance() {
        return tripDistance;
    }

    public void setTripDistance(double tripDistance) {
        this.tripDistance = tripDistance;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public int getNoOfPassengers() {
        return noOfPassengers;
    }

    public void setNoOfPassengers(int noOfPassengers) {
        this.noOfPassengers = noOfPassengers;
    }

    public VehicleInfo getVehicleInfo() {
        return vehicleInfo;
    }

    public void setVehicleInfo(VehicleInfo vehicleInfo) {
        this.vehicleInfo = vehicleInfo;
    }

}
