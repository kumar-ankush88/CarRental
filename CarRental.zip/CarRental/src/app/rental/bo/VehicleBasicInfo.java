package app.rental.bo;

import java.io.Serializable;
import java.util.Date;

public class VehicleBasicInfo implements Serializable {
    private static final long serialVersionUID = -2087284434784489105L;

    private String manufacturer;

    private String modelName;

    private String chasisNo;

    private String registrationNumber;

    private Date registrationDate;

    private boolean isACEnabled;

    private int passengerLimit;

    public VehicleBasicInfo() {
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public String getChasisNo() {
        return chasisNo;
    }

    public void setChasisNo(String chasisNo) {
        this.chasisNo = chasisNo;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public Date getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(Date registrationDate) {
        this.registrationDate = registrationDate;
    }

    public boolean isACEnabled() {
        return isACEnabled;
    }

    public void setACEnabled(boolean isACEnabled) {
        this.isACEnabled = isACEnabled;
    }

    public int getPassengerLimit() {
        return passengerLimit;
    }

    public void setPassengerLimit(int passengerLimit) {
        this.passengerLimit = passengerLimit;
    }

}
