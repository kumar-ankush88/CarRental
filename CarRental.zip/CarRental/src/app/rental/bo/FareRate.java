package app.rental.bo;

import java.io.Serializable;

public class FareRate implements Serializable {

    private static final long serialVersionUID = 1L;

    private float standardRate;

    private float perKmACRate;

    private float extraPassengerPerKmRate;

    private float discountPercent;

    public FareRate() {
    }

    public float getStandardRate() {
        return standardRate;
    }

    public void setStandardRate(float standardRate) {
        this.standardRate = standardRate;
    }

    public float getPerKmACRate() {
        return perKmACRate;
    }

    public void setPerKmACRate(float perKmACRate) {
        this.perKmACRate = perKmACRate;
    }

    public float getExtraPassengerPerKmRate() {
        return extraPassengerPerKmRate;
    }

    public void setExtraPassengerPerKmRate(float extraPassengerPerKmRate) {
        this.extraPassengerPerKmRate = extraPassengerPerKmRate;
    }

    public float getDiscountPercent() {
        return discountPercent;
    }

    public void setDiscountPercent(float discountPercent) {
        this.discountPercent = discountPercent;
    }

}
